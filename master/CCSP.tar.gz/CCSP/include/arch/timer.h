#ifndef _ARCH_TIMER_H
#define _ARCH_TIMER_H

#ifdef TARGET_CPU_386
#include <i386/timer.h>
#endif

#endif /* !_ARCH_TIMER_H */
