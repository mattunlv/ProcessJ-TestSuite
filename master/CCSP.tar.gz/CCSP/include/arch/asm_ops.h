#ifndef _ARCH_ASM_OPS_H
#define _ARCH_ASM_OPS_H

#ifdef TARGET_CPU_386
#include <i386/asm_ops.h>
#endif

#endif /* !_ARCH_ASM_OPS_H */
