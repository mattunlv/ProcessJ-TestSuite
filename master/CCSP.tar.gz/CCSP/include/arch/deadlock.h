#ifndef _ARCH_DEADLOCK_H
#define _ARCH_DEADLOCK_H

#ifdef TARGET_CPU_386
#include <i386/deadlock.h>
#endif

#endif /* !_ARCH_DEADLOCK_H */
