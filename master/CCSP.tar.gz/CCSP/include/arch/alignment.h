#ifndef _ARCH_ALIGNMENT_H
#define _ARCH_ALIGNMENT_H

#ifdef TARGET_CPU_386
#include <i386/alignment.h>
#endif

#endif /* _ARCH_ALIGNMENT_H */
