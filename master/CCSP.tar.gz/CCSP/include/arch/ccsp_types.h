#ifndef _ARCH_CCSP_TYPES_H
#define _ARCH_CCSP_TYPES_H

#ifdef TARGET_CPU_386
#include <i386/ccsp_types.h>
#endif

#endif /* !_ARCH_CCSP_TYPES_H */
